// Projet : Synthèse d'Image - Araignée en OpenGL
// Auteurs : LAWSON et SENOU
// Fichier : araignee.cpp
// Description :
// Ce fichier contient toutes les fonctions de modélisation et d'assemblage.
// On y trouve les calculs mathématiques pour générer les formes de base
// (la sphère, l'ovale de l'abdomen et les cylindres pour les pattes),
// ainsi que la fonction principale qui assemble le corps de l'araignée.
// C'est aussi ici que sont gérées les animations (la respiration, la marche
// automatique et le mouvement de salut)

#include "araignee.h"
#include <GL/glut.h>
#include <cmath>

extern GLuint texCorps; // <- Les textures sont déclarées dans main.cpp
extern GLuint texSol;
extern float phase;
extern float phaseSalut;
extern bool salut;

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// Fonction pour dessiner une sphère.
// On calcule les sommets avec des coordonnées sphériques (phi, theta)
// et on ajoute les coordonnées de texture (u,v).
void dessinerSphere(float rayon, int tranches, int anneaux)
{
    glBegin(GL_QUADS);
    for (int i = 0; i < anneaux; ++i)
    {
        // Latitude
        float phi1 = M_PI * i / anneaux;
        float phi2 = M_PI * (i + 1) / anneaux;

        for (int j = 0; j < tranches; ++j)
        {
            // Longitude
            float theta1 = 2.0f * M_PI * j / tranches;
            float theta2 = 2.0f * M_PI * (j + 1) / tranches;

            // Coordonnées de texture
            float u1 = (float)j / tranches;
            float u2 = (float)(j + 1) / tranches;
            float v1 = (float)i / anneaux;
            float v2 = (float)(i + 1) / anneaux;

            // Calcul des 4 sommets de la facette
            // Sommet 1
            float x1 = rayon * sin(phi1) * cos(theta1);
            float y1 = rayon * cos(phi1);
            float z1 = rayon * sin(phi1) * sin(theta1);

            // Sommet 2
            float x2 = rayon * sin(phi2) * cos(theta1);
            float y2 = rayon * cos(phi2);
            float z2 = rayon * sin(phi2) * sin(theta1);

            // Sommet 3
            float x3 = rayon * sin(phi2) * cos(theta2);
            float y3 = rayon * cos(phi2);
            float z3 = rayon * sin(phi2) * sin(theta2);

            // Sommet 4
            float x4 = rayon * sin(phi1) * cos(theta2);
            float y4 = rayon * cos(phi1);
            float z4 = rayon * sin(phi1) * sin(theta2);

            // Normales + Coordonnées de texture + Vertices
            // Sommet 1 : (u1, v1)
            glNormal3f(x1, y1, z1);
            glTexCoord2f(u1, v1);
            glVertex3f(x1, y1, z1);

            // Sommet 2 : (u1, v2)
            glNormal3f(x2, y2, z2);
            glTexCoord2f(u1, v2);
            glVertex3f(x2, y2, z2);

            // Sommet 3 : (u2, v2)
            glNormal3f(x3, y3, z3);
            glTexCoord2f(u2, v2);
            glVertex3f(x3, y3, z3);

            // Sommet 4 : (u2, v1)
            glNormal3f(x4, y4, z4);
            glTexCoord2f(u2, v1);
            glVertex3f(x4, y4, z4);
        }
    }
    glEnd();
}

// On a essayé de transformer la sphère en ovale avec glScalef, mais la lumière
// rendait mal. Du coup on a créé cette fonction en modifiant directement le rayon.
void dessinerOvale(float rayon, int tranches, int anneaux)
{
    glBegin(GL_QUADS);
    for (int i = 0; i < anneaux; ++i)
    {
        float phi1 = M_PI * i / anneaux;
        float phi2 = M_PI * (i + 1) / anneaux;

        // Facteur de grosseur de chaque anneau : 0.6 côté tête -> 1.1 côté arrière
        float g1 = 0.6f + 0.5f * (1.0f - cos(phi1)) / 2.0f;
        float g2 = 0.6f + 0.5f * (1.0f - cos(phi2)) / 2.0f;

        for (int j = 0; j < tranches; ++j)
        {
            float theta1 = 2.0f * M_PI * j / tranches;
            float theta2 = 2.0f * M_PI * (j + 1) / tranches;

            // Coordonnées de texture
            float u1 = (float)j / tranches;
            float u2 = (float)(j + 1) / tranches;
            float v1 = (float)i / anneaux;
            float v2 = (float)(i + 1) / anneaux;

            // Sommet 1
            float x1 = -1.3f * rayon * cos(phi1);
            float y1 = rayon * g1 * sin(phi1) * cos(theta1);
            float z1 = rayon * g1 * sin(phi1) * sin(theta1);

            // Sommet 2
            float x2 = -1.3f * rayon * cos(phi2);
            float y2 = rayon * g2 * sin(phi2) * cos(theta1);
            float z2 = rayon * g2 * sin(phi2) * sin(theta1);

            // Sommet 3
            float x3 = -1.3f * rayon * cos(phi2);
            float y3 = rayon * g2 * sin(phi2) * cos(theta2);
            float z3 = rayon * g2 * sin(phi2) * sin(theta2);

            // Sommet 4
            float x4 = -1.3f * rayon * cos(phi1);
            float y4 = rayon * g1 * sin(phi1) * cos(theta2);
            float z4 = rayon * g1 * sin(phi1) * sin(theta2);

            glNormal3f(x1, y1, z1); glTexCoord2f(u1, v1); glVertex3f(x1, y1, z1);
            glNormal3f(x2, y2, z2); glTexCoord2f(u1, v2); glVertex3f(x2, y2, z2);
            glNormal3f(x3, y3, z3); glTexCoord2f(u2, v2); glVertex3f(x3, y3, z3);
            glNormal3f(x4, y4, z4); glTexCoord2f(u2, v1); glVertex3f(x4, y4, z4);
        }
    }
    glEnd();
}

// Rayon d'un anneau : interpolé de r1 à r2, avec un "pli" (anneau plus gros) un sur deux
// Ça donne un aspect un peu "organique" aux pattes.
static float rayonAnneau(float r1, float r2, int k, int segments) {
    float r = r1 + (r2 - r1) * k / segments;
    if (k > 0 && k < segments && k % 2 == 1) r *= 1.2f;
    return r;
}

// Cylindre facetté le long de +Y, de y=0 à y=longueur
void dessinerCylindrePlis(float r1, float r2, float longueur, int tranches, int segments) {
    for (int k = 0; k < segments; ++k) {
        float ra = rayonAnneau(r1, r2, k, segments);
        float rb = rayonAnneau(r1, r2, k + 1, segments);
        float ya = longueur * k / segments;
        float yb = longueur * (k + 1) / segments;

        glBegin(GL_QUADS);
        for (int j = 0; j < tranches; ++j) {
            float th1 = 2.0f * M_PI * j / tranches;
            float th2 = 2.0f * M_PI * (j + 1) / tranches;

            float p1[3] = {ra * cosf(th1), ya, ra * sinf(th1)};
            float p2[3] = {rb * cosf(th1), yb, rb * sinf(th1)};
            float p3[3] = {rb * cosf(th2), yb, rb * sinf(th2)};
            float p4[3] = {ra * cosf(th2), ya, ra * sinf(th2)};

            // Normale PAR FACE (produit vectoriel) -> aspect facetté
            float u[3] = {p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]};
            float v[3] = {p4[0] - p1[0], p4[1] - p1[1], p4[2] - p1[2]};
            glNormal3f(u[1] * v[2] - u[2] * v[1],
                       u[2] * v[0] - u[0] * v[2],
                       u[0] * v[1] - u[1] * v[0]);

            float u1 = (float)j / tranches;
            float u2 = (float)(j + 1) / tranches;
            float v1 = (float)k / segments;
            float v2 = (float)(k + 1) / segments;

            glTexCoord2f(u1, v1); glVertex3fv(p1);
            glTexCoord2f(u1, v2); glVertex3fv(p2);
            glTexCoord2f(u2, v2); glVertex3fv(p3);
            glTexCoord2f(u2, v1); glVertex3fv(p4);

        }
        glEnd();
    }

    // Bouchon au bout
    glBegin(GL_POLYGON);
    glNormal3f(0.0f, 1.0f, 0.0f);
    for (int j = 0; j < tranches; ++j) {
        float th = 2.0f * M_PI * j / tranches;
        glTexCoord2f(0.5f + 0.5f * cosf(th), 0.5f + 0.5f * sinf(th));
        glVertex3f(r2 * cosf(th), longueur, r2 * sinf(th));
    }
    glEnd();
}

// Une patte est composée de 3 segments (fémur, tibia, pied).
// On utilise la pile de matrices pour bien positionner chaque segment.
void dessinerPatte(float angleEpaule, float angleGenou) {
    glPushMatrix();
        // Rotation autour de Z : la patte penche sur le côté (vers +X ou -X)
        glRotatef(angleEpaule, 0.0, 0.0, 1.0);
        dessinerCylindrePlis(0.06f, 0.04f, 0.5f, 6, 2);

        glTranslatef(0.0, 0.5, 0.0);
        glRotatef(angleGenou, 0.0, 0.0, 1.0);
        dessinerCylindrePlis(0.04f, 0.02f, 0.6f, 6, 2);

        glTranslatef(0.0, 0.6, 0.0);
        glRotatef(angleGenou * 0.5f, 0.0, 0.0, 1.0);
        dessinerCylindrePlis(0.02f, 0.01f, 0.3f, 6, 2);
    glPopMatrix();
}

void dessinerAraignee()
{
    // L'ABDOMEN (avec texture enroulée)
    glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, texCorps); // <-- Lier la texture
        glTranslatef(0.0f, 0.0f, 0.0f);
        glRotatef(15.0f, 0.0f, 0.0f, 1.0f);
        float respire = sinf(phase * 0.5f);   // oscille entre -1 et +1
        glScalef(1.0f + 0.03f * respire,      // longueur : +/- 3 %
                 1.0f + 0.05f * respire,      // hauteur : +/- 5 %
                 1.0f + 0.05f * respire);     // largeur : +/- 5 %
        dessinerOvale(1.0f, 20, 20);
    glPopMatrix();

    // LE CÉPHALOTHORAX + TÊTE
    glPushMatrix();
        glTranslatef(-1.9f, 0.0f, 0.0f);

        // Corps : sphère aplatie (avec texture)
        glPushMatrix();
            glBindTexture(GL_TEXTURE_2D, texCorps); // <-- Lier la texture
            glScalef(0.9f, 0.55f, 0.7f);
            dessinerSphere(1.0f, 24, 24);
        glPopMatrix();

        // LES YEUX
        // On désactive la texture et la lumière pour que les yeux soient bien noirs
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_LIGHTING);
        glColor3f(0.0f, 0.0f, 0.0f); // Yeux noirs

        const float yeux[4][3] = {
            {38.0f, 10.0f, 0.09f},
            {25.0f, 32.0f, 0.08f},
            {50.0f, 30.0f, 0.07f},
            {62.0f, 10.0f, 0.06f}
        };
        for (int e = 0; e < 4; e++) {
            float a = yeux[e][0] * M_PI / 180.0f;
            float b = yeux[e][1] * M_PI / 180.0f;
            float x = -0.9f * cosf(a) * cosf(b);
            float y =  0.55f * sinf(a);
            float z =  0.7f * cosf(a) * sinf(b);
            for (int c = -1; c <= 1; c += 2) {
                glPushMatrix();
                    glTranslatef(x, y, z * c);
                    dessinerSphere(yeux[e][2], 10, 10);
                glPopMatrix();
            }
        }
        // Réactiver la texture et l'éclairage
        glEnable(GL_LIGHTING);
        glEnable(GL_TEXTURE_2D);
        glColor3f(1.0f, 1.0f, 1.0f);

        // les crochets
        glBindTexture(GL_TEXTURE_2D, texCorps);
        for (int c = -1; c <= 1; c += 2) {
            glPushMatrix();
                glTranslatef(-0.78f, -0.15f, 0.14f * c);
                glRotatef(165.0f, 0.0f, 0.0f, 1.0f);
                dessinerCylindrePlis(0.06f, 0.03f, 0.25f, 6, 3);
            glPopMatrix();
        }

        // LES PÉDIPALPES (petites pattes avant)
        for (int c = -1; c <= 1; c += 2) {
            glPushMatrix();
                glTranslatef(-0.7f, -0.2f, 0.4f * c);
                glRotatef(c * 110.0f, 1.0f, 0.0f, 0.0f);
                dessinerCylindrePlis(0.07f, 0.06f, 0.35f, 6, 2);
                glTranslatef(0.0f, 0.35f, 0.0f);
                glRotatef(c * 50.0f, 1.0f, 0.0f, 0.0f);
                dessinerCylindrePlis(0.06f, 0.04f, 0.3f, 6, 2);
            glPopMatrix();
        }

    glPopMatrix(); // Fin céphalothorax

    // LES PATTES
    glBindTexture(GL_TEXTURE_2D, texCorps); // Lier la texture pour les pattes

    // 4 pattes de chaque côté : c = +1 droite, c = -1 gauche
    for (int c = -1; c <= 1; c += 2) {
        for (int i = 0; i < 4; ++i) {
            glPushMatrix();
                glTranslatef(-2.2f + i * 0.3f, -0.1f, 0.5f * c);
                glRotatef(c * (60.0f + i * 20.0f), 0.0f, 1.0f, 0.0f);

                // Marche : pattes alternées (paires/impaires, gauche/droite en opposition)
                float dephasage = ((i % 2) ? (float)M_PI : 0.0f) + ((c > 0) ? (float)M_PI : 0.0f);
                float osc = 15.0f * sinf(phase + dephasage);
                float epaule = 60.0f + osc;
                float genou  = 60.0f - osc;

                // Salut : les deux pattes avant se lèvent et s'agitent
                if (salut && i == 0) {
                    epaule = 20.0f + 15.0f * sinf(phaseSalut);
                    genou  = 80.0f + 20.0f * sinf(phaseSalut);
                }

                dessinerPatte(epaule, genou);
            glPopMatrix();
        }
    }
}

void dessinerFond() {
    // Le fond ignore la profondeur et la lumière
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texSol);   // ou une autre texture de fond
    glColor3f(1.0f, 1.0f, 1.0f);

    // Projection 2D temporaire : (0,0) en bas à gauche, (1,1) en haut à droite
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();

    glBegin(GL_QUADS);
        glTexCoord2f(0.0f, 0.0f); glVertex2f(0.0f, 0.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex2f(1.0f, 0.0f);
        glTexCoord2f(1.0f, 1.0f); glVertex2f(1.0f, 1.0f);
        glTexCoord2f(0.0f, 1.0f); glVertex2f(0.0f, 1.0f);
    glEnd();

    // Retour à la projection et à la vue normales
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

    glEnable(GL_LIGHTING);
    glEnable(GL_DEPTH_TEST);
}

void dessinerSol() {
    glBindTexture(GL_TEXTURE_2D, texSol);
    glBegin(GL_QUADS);
        glNormal3f(0.0, 1.0, 0.0); // Normale vers le haut (pour la lumière)
        glTexCoord2f(0.0, 0.0); glVertex3f(-10.0, -1.5, -10.0);
        glTexCoord2f(0.0, 1.0); glVertex3f(-10.0, -1.5,  10.0);
        glTexCoord2f(1.0, 1.0); glVertex3f( 10.0, -1.5,  10.0);
        glTexCoord2f(1.0, 0.0); glVertex3f( 10.0, -1.5, -10.0);
    glEnd();
}
