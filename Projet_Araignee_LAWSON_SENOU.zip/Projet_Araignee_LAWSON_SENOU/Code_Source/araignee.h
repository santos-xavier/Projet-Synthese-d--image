// Projet : Synth�se d'Image - Araign�e en OpenGL
// Auteurs : LAWSON et SENOU
// Fichier : araignee.h
// Description :
// Fichier d'en-t�te. Il contient les prototypes de toutes les fonctions
// du fichier araignee.cpp pour que main.cpp puisse les utiliser.

#ifndef ARAIGNEE_H
#define ARAIGNEE_H

// Fonctions de base pour dessiner les formes
// (On a d� les coder � la main car on n'a pas le droit d'utiliser gluSphere)
void dessinerSphere(float rayon, int tranches, int anneaux);
void dessinerOvale(float rayon, int tranches, int anneaux);
void dessinerCylindrePlis(float r1, float r2, float longueur, int tranches, int segments);

// Fonctions pour construire l'araign�e
void dessinerPatte(float angleEpaule, float angleGenou);
void dessinerAraignee();

//Pour le d�cor
void dessinerFond();
void dessinerSol();

#endif
