// Projet : Synthèse d'Image - Araignée en OpenGL
// Auteurs : LAWSON et SENOU
// Fichier : main.cpp
// Description :
// Ce fichier est le point d'entrée du programme. Il s'occupe de créer la
// fenêtre, de configurer la caméra et les deux lumières, et de charger
// les textures (avec le code JPEG du TP). C'est aussi ici qu'on gère
// les touches du clavier pour déclencher les animations.

#include <GL/glut.h>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <jpeglib.h>
#include <jerror.h>
#include "araignee.h"

// Variables pour la caméra
float angleX = 0.0f, angleY = 0.0f;
float zoom = 10.0f;

// Variables pour gérer les animations
float phase = 0.0f;        // Sert pour la marche automatique
float phaseSalut = 0.0f;   // Sert quand on appuie sur 'a'
bool salut = false;        // Est-ce que l'araignée salue ?
bool rotationAuto = false; // Est-ce que l'araignée tourne toute seule ?

// Tableaux pour stocker les textures (récupéré sur Plubel)
unsigned char imageCorps[256*256*3]; //<-Pour le corps
unsigned char imageSol[256*256*3];//<- Pour le sol

GLuint texCorps;
GLuint texSol;

// Prototypes
void affichage();
void clavier(unsigned char touche, int x, int y);
void clavierSpecial(int touche, int x, int y);
void redimensionner(int largeur, int hauteur);
void initialiserLumieres();
void timer(int valeur);

// Fonction pour charger les images JPEG (reprise du TP sur les Textures)
// On a dû modifier la fonction du TP pour ajouter un paramètre 'tableauImage'.
// Parce qu'on a besoin de charger 2 textures différentes (corps et sol).
// Du coup, au lieu d'utiliser une variable globale unique, on passe le tableau en paramètre.
// les images doivent obligatoirement faire 256x256 pixels si non erreur à la compilation
void chargerImageJPEG(char *fichier, unsigned char* tableauImage) {
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE *file;
    unsigned char *ligne;

    cinfo.err = jpeg_std_error(&jerr);
    jpeg_create_decompress(&cinfo);

    if ((file = fopen(fichier,"rb")) == 0) {
        fprintf(stderr,"Erreur : impossible d'ouvrir le fichier %s\n", fichier);
        exit(1);
    }
    jpeg_stdio_src(&cinfo, file);
    jpeg_read_header(&cinfo, TRUE);

    // On vérifie la taille de l'image pour éviter les bugs
    if ((cinfo.image_width!=256)||(cinfo.image_height!=256)) {
        fprintf(stdout,"Erreur : l'image %s doit etre de taille 256x256\n", fichier);
        exit(1);
    }

    jpeg_start_decompress(&cinfo);
    ligne = tableauImage;
    while (cinfo.output_scanline < cinfo.output_height) {
        ligne = tableauImage + 3*256*cinfo.output_scanline;
        jpeg_read_scanlines(&cinfo, &ligne, 1);
    }
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    fclose(file);
}

int main(int argc, char **argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitWindowSize(800, 800);
    glutCreateWindow("Projet Araignee - LAWSON SENOU");

    // Activation du Z-buffer et de l'éclairage
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    initialiserLumieres();

    // Enregistrement des callbacks (fonctions appelées par OpenGL)
    glutDisplayFunc(affichage);
    glutKeyboardFunc(clavier);
    glutSpecialFunc(clavierSpecial);
    glutReshapeFunc(redimensionner);

    // Chargement des textures (on a galéré à cause de la DLL...) ---
    chargerImageJPEG("textures/corps.jpg", imageCorps);
    chargerImageJPEG("textures/sol.jpg", imageSol);

    glEnable(GL_TEXTURE_2D);

    // Texture du corps de l'araignée
    glGenTextures(1, &texCorps);
    glBindTexture(GL_TEXTURE_2D, texCorps);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    // On utilise GL_REPEAT pour que la texture se répète bien sur les pattes
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, imageCorps);

    // Texture du sol
    glGenTextures(1, &texSol);
    glBindTexture(GL_TEXTURE_2D, texSol);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, 256, 256, 0, GL_RGB, GL_UNSIGNED_BYTE, imageSol);

    glutTimerFunc(16, timer, 0); // Lance la boucle d'animation (~60 FPS)
    glutMainLoop();
    return 0;
}

// Mise en place des 2 lumières
void initialiserLumieres() {
    // Lumière 0 : classique, blanche (haut/avant droit)
    GLfloat lumiereDiffuse[]  = {1.0, 1.0, 1.0, 1.0};
    GLfloat lumiereAmbiante[] = {0.2, 0.2, 0.2, 1.0};
    GLfloat positionLumiere[] = {5.0, 5.0, 5.0, 1.0};
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lumiereDiffuse);
    glLightfv(GL_LIGHT0, GL_AMBIENT, lumiereAmbiante);
    glLightfv(GL_LIGHT0, GL_POSITION, positionLumiere);

    // Lumière 1 : bleutée directionnelle (on peut l'éteindre avec 'l')
    GLfloat diffuse1[]   = {0.3, 0.3, 0.7, 1.0};
    GLfloat specular1[]  = {0.0, 0.0, 0.0, 1.0};
    GLfloat direction1[] = {-1.0, 0.5, -1.0, 0.0};
    glEnable(GL_LIGHT1);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse1);
    glLightfv(GL_LIGHT1, GL_SPECULAR, specular1);
    glLightfv(GL_LIGHT1, GL_POSITION, direction1);
}

// C'est cette fonction qui fait avancer le temps pour les animations
void timer(int valeur) {
    phase += 0.15f;
    if (salut) phaseSalut += 0.25f;
    if (rotationAuto) angleY += 0.5f;

    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

void affichage() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    dessinerFond(); // L'image de fond (2D)

    glLoadIdentity();

    // Placement de la caméra
    glTranslatef(0.0, 0.0, -zoom);
    glRotatef(angleX, 1.0, 0.0, 0.0);
    glRotatef(angleY, 0.0, 1.0, 0.0);

    // Dessin de l'araignée
    dessinerAraignee();

    glutSwapBuffers();
}

void clavier(unsigned char touche, int x, int y) {
    switch (touche) {
        case 'Z': zoom -= 0.5f; if (zoom < 1.0f) zoom = 1.0f; break;
        case 'z': zoom += 0.5f; break;
        case 'a': case 'A': salut = !salut; break;
        case 'r': case 'R': rotationAuto = !rotationAuto; break;
        case 'l': case 'L':
            if (glIsEnabled(GL_LIGHT1)) glDisable(GL_LIGHT1);
            else glEnable(GL_LIGHT1);
            break;
        case 27: case 'q': exit(0); break;
    }
    glutPostRedisplay();
}

void clavierSpecial(int touche, int x, int y) {
    switch (touche) {
        case GLUT_KEY_LEFT:  angleY -= 5.0f; break;
        case GLUT_KEY_RIGHT: angleY += 5.0f; break;
        case GLUT_KEY_UP:    angleX -= 5.0f; break;
        case GLUT_KEY_DOWN:  angleX += 5.0f; break;
    }
    glutPostRedisplay();
}

void redimensionner(int largeur, int hauteur) {
    if (hauteur == 0) hauteur = 1;
    float ratio = (float)largeur / (float)hauteur;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, ratio, 1.0, 100.0); // Projection perspective

    glMatrixMode(GL_MODELVIEW);
    glViewport(0, 0, largeur, hauteur);
}
